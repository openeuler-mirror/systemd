/* SPDX-License-Identifier: LGPL-2.1+ */
#pragma once

#include "install.h"

int verify_conditions(char **lines, UnitFileScope scope);
